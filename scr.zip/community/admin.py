from django.contrib import admin
from .models import doubt # Importing the doubt model

# Register your models here.
admin.site.register(doubt) # Registering the doubt model
